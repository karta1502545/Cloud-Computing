from pyspark import SparkContext
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType, IntegerType
from pyspark.sql import SparkSession

sc = SparkContext()
spark = SparkSession.builder.getOrCreate()

def load_data(filepath):
    rdd = sc.textFile(filepath)
    rdd = rdd.map(lambda line: line.split('\t'))
    rdd = rdd.map(lambda x: (x[0], int(x[1]), int(x[2]), int(x[3])))

    schema = StructType([
        StructField("word", StringType(), True),
        StructField("year", IntegerType(), True),
        StructField("frequency", IntegerType(), True),
        StructField("books", IntegerType(), True)
    ])

    df = spark.createDataFrame(rdd, schema)
    
    return rdd, df

filepath = 'gbooks'
rdd, df = load_data(filepath)
# df.createOrReplaceTempView("data_table")
# attribute_count_sql = spark.sql("SELECT word, COUNT(1) FROM data_table GROUP BY word ORDER BY COUNT(1) DESC")
# attribute_count_sql.show(3)

####
# 1. Setup : Write a function to load it in an RDD & DataFrame
####

# RDD API
# Columns:
# 0: word (string), 1: year (int), 2: frequency (int), 3: books (int)


# Spark SQL - DataFrame API


####
# 5. Joining : The following program construct a new dataframe out of 'df' with a much smaller size.
####

df2 = df.select("word", "year").distinct().limit(100)
df2.createOrReplaceTempView('gbooks2')
sql_result = spark.sql("SELECT a.*, b.* FROM gbooks2 a JOIN gbooks2 b ON a.year = b.year")
row_count = sql_result.count()
print(row_count)

# Now we are going to perform a JOIN operation on 'df2'. Do a self-join on 'df2' in lines with the same #'count1' values and see how many lines this JOIN could produce. Answer this question via Spark SQL API

# Spark SQL API

# output: 166

