from pyspark import SparkContext
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType, IntegerType
from pyspark.sql import SparkSession

sc = SparkContext()
spark = SparkSession.builder.getOrCreate()

def load_data(filepath):
    rdd = sc.textFile(filepath)
    rdd = rdd.map(lambda line: line.split('\t'))
    rdd = rdd.map(lambda x: (x[0], int(x[1]), int(x[2]), int(x[3])))

    schema = StructType([
        StructField("word", StringType(), True),
        StructField("year", IntegerType(), True),
        StructField("frequency", IntegerType(), True),
        StructField("books", IntegerType(), True)
    ])

    df = spark.createDataFrame(rdd, schema)
    
    return rdd, df

filepath = 'gbooks'
rdd, df = load_data(filepath)
df.createOrReplaceTempView("data_table")
attribute_count_sql = spark.sql("SELECT COUNT(1) FROM data_table WHERE word = 'ATTRIBUTE'")
attribute_count_sql.show()



####
# 1. Setup : Write a function to load it in an RDD & DataFrame
####

# RDD API
# Columns:
# 0: word (string), 1: year (int), 2: frequency (int), 3: books (int)

# Spark SQL - DataFrame API

####
# 3. Filtering : Count the number of appearances of word 'ATTRIBUTE'
####

# Spark SQL

# +--------+
# |count(1)|
# +--------+
# |      11|
# +--------+


