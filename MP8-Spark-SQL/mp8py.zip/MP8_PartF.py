from pyspark.sql.functions import col, lag
from pyspark import SparkContext
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType, IntegerType
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark.sql.functions import *

sc = SparkContext()
spark = SparkSession.builder.getOrCreate()

def load_data(filepath):
    rdd = sc.textFile(filepath)
    rdd = rdd.map(lambda line: line.split('\t'))
    rdd = rdd.map(lambda x: (x[0], int(x[1]), int(x[2]), int(x[3])))

    schema = StructType([
        StructField("word", StringType(), True),
        StructField("year", IntegerType(), True),
        StructField("frequency", IntegerType(), True),
        StructField("books", IntegerType(), True)
    ])

    df = spark.createDataFrame(rdd, schema)
    
    return rdd, df

filepath = 'gbooks'
rdd, df = load_data(filepath)
filtered_df = df.filter((col("year") > 1500) & (col("year") <= 2000))
window = Window.partitionBy("word").orderBy("year")
new_df = filtered_df.withColumn("frequency_increase", lead("frequency", 1).over(window))
total_increase_df = new_df.groupBy("word") \
                      .agg(sum("frequency_increase").alias("total_increase")) \
                      .orderBy(col("total_increase").desc())
total_increase_df.show(20)
####
# 1. Setup : Write a function to load it in an RDD & DataFrame
####

# RDD API
# Columns:
# 0: word (string), 1: year (int), 2: frequency (int), 3: books (int)


###
# 2. Frequency Increase : analyze the frequency increase of words starting from the year 1500 to the year 2000
###
# Spark SQL - DataFrame API


# df_word_increase.show()